<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">

<!--
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
-->

<html>
 <head><title>Login Page</title></head>
 <body>
 <center>
  <form method="post" action="/BinweiQi/LoginServlet">
  <h4>Enter your User ID and Password and click Login</h4>
  <table cellpadding='2' cellspacing='1'>
    <tr>
        <td>User ID</td>
        <td><input type="TEXT" size="15" name="userid"></input></td>
    </tr>
    <tr>
        <td>Password</td>
        <td><input type="PASSWORD" size="15" name="password"/></td>
    </tr>
    <tr>
        <td colspan='2'>
            <center><input type="submit" value="Login" /></center>
        </td>
    </tr>
 </table>
 </form>
 </center>
 </body>
</html>